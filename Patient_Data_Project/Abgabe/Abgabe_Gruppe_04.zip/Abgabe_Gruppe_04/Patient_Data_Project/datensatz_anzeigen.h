#ifndef DATENSATZ_ANZEIGEN_H
#define DATENSATZ_ANZEIGEN_H

#include <QDialog>
#include <QCloseEvent>
#include "io_data.h"
#include "database.h"
#include "mainwindow.h"
#include "user.h"
namespace Ui {
class datensatz_anzeigen;
}

class datensatz_anzeigen : public QDialog
{
    Q_OBJECT

public:
    Database *db;
    MainWindow *mw;
    int selectID;
    explicit datensatz_anzeigen(QWidget *parent = nullptr, Database* db=nullptr,int selectID=-1);
    ~datensatz_anzeigen();

protected:
    void closeEvent(QCloseEvent *event) override;  // closeEvent überschreiben

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_datensatz_anzeigen_rejected();

    void on_datensatz_anzeigen_finished(int result);

private:
    Ui::datensatz_anzeigen *ui;
};

#endif // DATENSATZ_ANZEIGEN_H
